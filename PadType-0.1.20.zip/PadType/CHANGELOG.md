# Changelog

## 0.1.20 — 2026-10-12

Initial publication package of the current prototype.

- Radial gamepad keyboard with letters, numbers, symbols, and Shift.
- Quick chat commands for say, party, raid, and reply.
- Adjustable size and background color saved across reloads.
- Right-stick positioning and a line connecting the keyboard to the focused field.
- Segmented character wedges, button icons, and fading header/footer styling.

Known limitations:

- Targets WoW Forever Beta, client 1.60.1 / Interface 16001.
- Auction-house text fields are excluded because of a native gamepad protected-action error.
- Movement-stick setting changes are disabled; movement may remain active while typing.
- Native EditBox insertion through securecallfunction is experimental.
