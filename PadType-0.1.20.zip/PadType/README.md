# PadType

PadType is a prototype radial on-screen keyboard for WoW Forever Beta (Interface 16001).
It opens when a text field has keyboard focus and sends gamepad input to that field.
Movement-stick setting changes are currently disabled to diagnose native gamepad
taint when closing the auction house. Movement may remain active while typing.
Text insertion now calls the native EditBox method through `securecallfunction`
when available, as an experimental isolation of Blizzard text-change callbacks.
PadType is disabled for auction-house text fields because typing there can trigger
a native gamepad protected-action error after searching and closing the window.
Use the physical keyboard for auction-house entry. Chat and other fields remain available.

## Install

Copy the `PadType` folder into `World of Warcraft/_classic_beta_/Interface/AddOns/`,
then enable it in the AddOns list. The native Gamepad UI must be enabled.

## Controls

- Move the left stick to point at one of the eight wedge-shaped character groups
  arranged around the center circle.
- Press Y, B, A, or X to choose the top, right, bottom, or left character.
- Center the left stick to select the middle circle: A = Space, X = Backspace,
  Y = Enter, and B = Escape.
- All face-button character labels are white.
- The center and right-trigger command groups remain circles; the eight outer
  groups are segmented wedges with slim bronze dividers and a gold selection glow.
  The outer wheel and its group positions are scaled to 80% while the center
  and command circles keep their current size.
- The four-character diamonds are centered within each wedge.
- Each character sits over its matching X, Y, B, or A button icon and briefly enlarges when chosen.
- The button icons are slightly enlarged, with no extra badge circles behind them.
- XYAB button textures use a single thin gold rim around their colored centers.
- The center actions use white Enter, Space, and Backspace symbols over the Y/A/X icons.
- Hold the right trigger to activate the command circle near the upper-right group:
  X = `/s `, Y = `/p `, B = `/raid `, and A = `/reply `.
- The panel uses a translucent grey radial wheel, gold trim and lettering,
  and warm highlighted rings inspired by the native Gamepad UI.
- The center action circle matches the command circle in size.
- The header and footer use translucent dark bands with thin dark-grey rules,
  inspired by Blizzard's gamepad main menu. The PadType title sits above the header.
- The header centers the page name and three circles, with the active page filled
  gold and LB/RB hints on either side. The footer shows Shift, Commands, Settings,
  and Close hints.
- LB/RB switch between letters, numbers, and symbols.
- Left trigger toggles Shift.
- Start opens Settings. D-pad up/down selects Size or Background; left/right
  adjusts the selected option (A also advances it). Mouse arrow buttons work too.
  Start or B returns to the keyboard; View closes it. Character input is suspended
  while Settings is open.
- Size ranges from 70% to 130% in 10% steps, defaulting to 100%. The new 100%
  baseline is 10% smaller than the original UI. Background presets are Grey,
  Bronze, Blue, Green, Plum, and Black. Size and color persist across reloads.
- Move the right stick to reposition PadType, including while Settings is open.
  The keyboard is kept within the screen. Mouse dragging remains available.
- A bronze line connects the edge of the active text box to the wheel. It follows
  both as they move and hides when the keyboard closes or the two overlap.
- The center Y action still inserts Enter. View closes the keyboard.
- `/padtype` toggles the keyboard for the currently focused text field.

The keyboard works with focused WoW EditBoxes, including common chat, mail, and
trade text fields. Auction-house fields are excluded. It is a first-pass prototype; please
verify field focus and control behavior in your 1.60.1 client.

## Release packaging

Run `python package_release.py` from `C:\Users\PaulR\OneDrive\Documents\PadType`
to build the CurseForge upload ZIP there. The archive includes one `PadType/` folder containing the addon,
textures, README, and changelog. Tests, tools, and publication notes are excluded.

