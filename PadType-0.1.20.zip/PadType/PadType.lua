local addonName = ...
local monitor = CreateFrame("Frame", "PadTypeFrame", UIParent)

local pages = {
    {
        name = "Letters",
        groups = {
            { "a", "b", "c", "d" }, { "e", "f", "g", "h" },
            { "i", "j", "k", "l" }, { "m", "n", "o", "p" },
            { "q", "r", "s", "t" }, { "u", "v", "w", "x" },
            { "y", "z", "\\", "!" }, { ".", ",", "'", "?" },
        },
    },
    {
        name = "Numbers",
        groups = {
            { "1", "2", "3", "4" }, { "5", "6", "7", "8" },
            { "9", "0", "-", "_" }, { "+", "=", "(", ")" },
            { "!", "?", ":", ";" }, { "@", "#", "$", "%" },
            { "Space", "⌫", ".", "," }, { "'", "/", "\\", "Enter" },
        },
    },
    {
        name = "Symbols",
        groups = {
            { "!", "?", ".", "," }, { ":", ";", "'", '"' },
            { "@", "#", "$", "%" }, { "&", "*", "+", "=" },
            { "(", ")", "[", "]" }, { "{", "}", "<", ">" },
            { "-", "_", "/", "\\" }, { "Space", "⌫", "~", "Enter" },
        },
    },
}

local groupButtons = {} -- 1=up, 2=right, 3=down, 4=left (Y, B, A, X)
local centerGroup
local specialGroup
local activeEditBox
local dismissedEditBox
local currentGroup, currentPage = 0, 1
local isShifted = false
local specialMode = false
local stickDeadZone = 0.45
local baseScale = 0.90 -- Settings 100% means the new, 10% smaller baseline.
local preferences = { size = 100, background = 1 }
local backgroundColors = {
    { "Grey", 0.10, 0.10, 0.10 }, { "Bronze", 0.10, 0.065, 0.03 },
    { "Blue", 0.035, 0.065, 0.12 }, { "Green", 0.035, 0.10, 0.065 },
    { "Plum", 0.10, 0.045, 0.10 }, { "Black", 0.025, 0.025, 0.025 },
}
local menuBackgrounds = {}
local applyAppearance
local moveX, moveY = 0, 0
local settingsRow = 1

local panel = CreateFrame("Frame", "PadTypeKeyboard", UIParent, "BackdropTemplate")
panel:SetSize(540, 480)
panel:SetScale(baseScale)
panel:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
panel:SetFrameStrata("DIALOG")
panel:SetFrameLevel(100)
panel:SetClampedToScreen(true)
panel:EnableMouse(true)
panel:SetMovable(true)
panel:RegisterForDrag("LeftButton")
panel:SetScript("OnDragStart", panel.StartMoving)
panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
panel:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 },
})
panel:SetBackdropColor(0.025, 0.018, 0.012, 0)
panel:SetBackdropBorderColor(0.43, 0.31, 0.16, 0)
panel:Hide()

-- Quiet translucent bands and fine dark-grey rules, like the native gamepad menu.
local function colorBand(band, r, g, b, alpha)
    for _, segment in ipairs(band) do
        segment.texture:SetColorTexture(1, 1, 1, 1)
        segment.texture:SetGradient("HORIZONTAL",
            CreateColor(r, g, b, alpha * segment.leftAlpha),
            CreateColor(r, g, b, alpha * segment.rightAlpha))
    end
end

local function createBand(parent, layer, fadeEdges)
    local band = {}
    local function segment(leftAlpha, rightAlpha)
        local texture = parent:CreateTexture(nil, layer)
        band[#band + 1] = { texture = texture, leftAlpha = leftAlpha, rightAlpha = rightAlpha }
        return texture
    end
    if fadeEdges then
        local left, center, right = segment(0, 1), segment(1, 1), segment(1, 0)
        left:SetPoint("TOPLEFT")
        left:SetPoint("BOTTOMLEFT")
        left:SetWidth(90)
        right:SetPoint("TOPRIGHT")
        right:SetPoint("BOTTOMRIGHT")
        right:SetWidth(90)
        center:SetPoint("TOPLEFT", left, "TOPRIGHT")
        center:SetPoint("BOTTOMRIGHT", right, "BOTTOMLEFT")
    else
        segment(1, 1):SetAllPoints()
    end
    return band
end

local function createMenuBar(parent, fadeEdges)
    local bar = CreateFrame("Frame", nil, parent)
    local background = createBand(bar, "BACKGROUND", fadeEdges)
    colorBand(background, 0.018, 0.016, 0.012, 0.90)
    menuBackgrounds[#menuBackgrounds + 1] = background
    for _, edge in ipairs({ "TOP", "BOTTOM" }) do
        local trim = CreateFrame("Frame", nil, bar)
        trim:SetPoint(edge .. "LEFT")
        trim:SetPoint(edge .. "RIGHT")
        trim:SetHeight(1)
        colorBand(createBand(trim, "BORDER", fadeEdges), 0.25, 0.25, 0.25, 0.85)
    end
    return bar
end

local header = createMenuBar(panel, true)
header:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -36)
header:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -8, -36)
header:SetHeight(58)
local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("BOTTOM", header, "TOP", 0, 8)
title:SetText("PadType")
title:SetTextColor(1, 0.97, 0.88)
title:SetShadowColor(0, 0, 0, 1)
title:SetShadowOffset(1, -2)

local pageLabel = header:CreateFontString(nil, "OVERLAY", "GameFontNormal")
pageLabel:SetPoint("TOP", header, "TOP", 0, -7)
pageLabel:SetTextColor(1, 0.82, 0)

local function createKeyHint(parent, text, x, y)
    local key = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    key:SetSize(32, 22)
    key:SetPoint("CENTER", parent, "CENTER", x, y)
    key:SetBackdrop({ bgFile = "Interface/Buttons/WHITE8X8",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", edgeSize = 8,
        insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    key:SetBackdropColor(0.025, 0.025, 0.022, 1)
    key:SetBackdropBorderColor(0.65, 0.61, 0.50, 1)
    local label = key:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("CENTER")
    label:SetText(text)
    return key
end

local pageDots = {}
for index = 1, #pages do
    local dot = CreateFrame("Frame", nil, header)
    dot:SetSize(16, 16)
    dot:SetPoint("CENTER", header, "CENTER", (index - (#pages + 1) / 2) * 25, -9)
    for _, layer in ipairs({ "rim", "fill" }) do
        local texture = dot:CreateTexture(nil, layer == "rim" and "BACKGROUND" or "ARTWORK")
        texture:SetSize(layer == "rim" and 16 or 12, layer == "rim" and 16 or 12)
        texture:SetPoint("CENTER")
        texture:SetColorTexture(0.65, 0.65, 0.59, 1)
        local mask = dot:CreateMaskTexture()
        mask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask")
        mask:SetAllPoints(texture)
        texture:AddMaskTexture(mask)
        dot[layer] = texture
    end
    pageDots[index] = dot
end
local shoulderOffset = (#pages - 1) * 12.5 + 34
createKeyHint(header, "LB", -shoulderOffset, -9)
createKeyHint(header, "RB", shoulderOffset, -9)

local footer = createMenuBar(panel, true)
footer:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 8, 8)
footer:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -8, 8)
footer:SetHeight(66)
local footerHints = {
    { "LT", "Shift" },
    { "Hold RT", "Commands" },
    { "", "Settings", "Interface\\AddOns\\PadType\\Textures\\start_button.png" },
    { "", "Close", "Interface\\AddOns\\PadType\\Textures\\view_button.png" },
}
for index, hint in ipairs(footerHints) do
    local x = (index - (#footerHints + 1) / 2) * 120
    local key
    if hint[3] then
        key = CreateFrame("Frame", nil, footer)
        key:SetSize(26, 26)
        key:SetPoint("CENTER", footer, "CENTER", x, 9)
        local icon = key:CreateTexture(nil, "ARTWORK")
        icon:SetTexture(hint[3])
        icon:SetSize(26, 26)
        icon:SetPoint("CENTER")
    else
        key = createKeyHint(footer, hint[1] == "Hold RT" and "RT" or hint[1], x, 9)
    end
    local action = footer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    action:SetPoint("TOP", key, "BOTTOM", 0, -4)
    action:SetText(hint[1] == "Hold RT" and "Hold: Commands" or hint[2])
    action:SetTextColor(1, 0.82, 0)
end

local settings = CreateFrame("Frame", nil, panel)
settings:SetAllPoints(panel)
settings:SetFrameLevel(panel:GetFrameLevel() + 20)
settings:EnableMouse(true)
local shade = settings:CreateTexture(nil, "BACKGROUND")
shade:SetAllPoints()
shade:SetColorTexture(0, 0, 0, 0.75)
local settingsCard = createMenuBar(settings)
settingsCard:SetSize(420, 250)
settingsCard:SetPoint("CENTER")
local settingsTitle = settingsCard:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
settingsTitle:SetPoint("TOP", 0, -20)
settingsTitle:SetText("PadType Settings")
settingsTitle:SetTextColor(1, 0.97, 0.88)
local settingLabels = {}
local function changeSetting(row, direction)
    if row == 1 then
        preferences.size = math.max(70, math.min(130, preferences.size + direction * 10))
    else
        preferences.background = ((preferences.background - 1 + direction) % #backgroundColors) + 1
    end
    if applyAppearance then applyAppearance() end
end
local function refreshSettings()
    settingLabels[1]:SetText("Size: " .. preferences.size .. "%")
    settingLabels[2]:SetText("Background: " .. backgroundColors[preferences.background][1])
    for row, label in ipairs(settingLabels) do
        if row == settingsRow then label:SetTextColor(1, 0.82, 0)
        else label:SetTextColor(0.85, 0.85, 0.85) end
    end
end
for row = 1, 2 do
    local label = settingsCard:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    label:SetPoint("TOP", 0, -62 - (row - 1) * 42)
    settingLabels[row] = label
    for _, direction in ipairs({ -1, 1 }) do
        local button = CreateFrame("Button", nil, settingsCard, "UIPanelButtonTemplate")
        button:SetSize(30, 26)
        button:SetPoint("CENTER", label, "CENTER", direction * 160, 0)
        button:SetText(direction < 0 and "<" or ">")
        button:SetScript("OnClick", function()
            settingsRow = row
            changeSetting(row, direction)
        end)
    end
end
local back = CreateFrame("Button", nil, settingsCard, "UIPanelButtonTemplate")
back:SetSize(140, 24)
back:SetPoint("BOTTOM", 0, 49)
back:SetText("Back to keyboard")
back:SetScript("OnClick", function() settings:Hide() end)
local settingsHint = settingsCard:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
settingsHint:SetPoint("BOTTOM", 0, 10)
settingsHint:SetText("D-pad: Select / Adjust   ·   Right stick: Move\nStart / B: Back   ·   View: Close")
refreshSettings()
settings:Hide()

local function makeText(parent, layer, template, text)
    local fs = parent:CreateFontString(nil, layer, template)
    fs:SetText(text)
    return fs
end

local function setButtonText(value)
    if value == "Space" then return "␠" end
    if value == "Enter" then return "↵" end
    if isShifted and value:match("^[a-z]$") then return value:upper() end
    return value
end

-- Each group is a small four-way diamond arranged around the center.
-- Center the character diamonds on the visual center of each annular wedge.
local groupRadius = 92
local buttonOffsets = {
    { 0, 15 }, { 19, 0 }, { 0, -15 }, { -19, 0 },
}
local faceColors = {
    { 0.88, 0.72, 0.18 }, -- Y, yellow, top
    { 0.82, 0.22, 0.18 }, -- B, red, right
    { 0.20, 0.65, 0.29 }, -- A, green, bottom
    { 0.22, 0.52, 0.96 }, -- X, blue, left
}
local buttonIconPaths = {
    [1] = "Interface\\AddOns\\PadType\\Textures\\y_button.png",
    [2] = "Interface\\AddOns\\PadType\\Textures\\b_button.png",
    [3] = "Interface\\AddOns\\PadType\\Textures\\a_button.png",
    [4] = "Interface\\AddOns\\PadType\\Textures\\x_button.png",
}
local centerActionIconPaths = {
    [1] = "Interface\\AddOns\\PadType\\Textures\\Enter.png",
    [3] = "Interface\\AddOns\\PadType\\Textures\\space_action.png",
    [4] = "Interface\\AddOns\\PadType\\Textures\\Backspace.png",
}

local function createCircle(frame, size)
    frame:SetSize(size, size)
    frame.outer = frame:CreateTexture(nil, "BACKGROUND")
    frame.outer:SetSize(size, size)
    frame.outer:SetPoint("CENTER")
    frame.outer:SetColorTexture(0.025, 0.025, 0.025, 1)
    local outerMask = frame:CreateMaskTexture()
    outerMask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask")
    outerMask:SetAllPoints(frame.outer)
    frame.outer:AddMaskTexture(outerMask)

    frame.rim = frame:CreateTexture(nil, "BORDER")
    frame.rim:SetSize(size - 3, size - 3)
    frame.rim:SetPoint("CENTER")
    frame.rim:SetColorTexture(0.43, 0.29, 0.13, 1)
    local rimMask = frame:CreateMaskTexture()
    rimMask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask")
    rimMask:SetAllPoints(frame.rim)
    frame.rim:AddMaskTexture(rimMask)

    frame.inner = frame:CreateTexture(nil, "ARTWORK")
    frame.inner:SetSize(size - 8, size - 8)
    frame.inner:SetPoint("CENTER")
    frame.inner:SetColorTexture(0.10, 0.10, 0.10, 0.97)
    local innerMask = frame:CreateMaskTexture()
    innerMask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask")
    innerMask:SetAllPoints(frame.inner)
    frame.inner:AddMaskTexture(innerMask)
end

local wheel = CreateFrame("Frame", nil, panel)
createCircle(wheel, 266)
wheel:SetPoint("CENTER", panel, "CENTER", 0, -12)
-- The wedges provide the wheel artwork; leave the space behind them clear.
wheel.outer:Hide()
wheel.rim:Hide()
wheel.inner:Hide()
local wedgeTexturePath = "Interface\\AddOns\\PadType\\Textures\\wedge_segment.png"
local wheelWedges = {}
local wheelWedgeFills = {}
for group = 1, 8 do
    local fill = wheel:CreateTexture(nil, "BACKGROUND")
    fill:SetTexture("Interface\\AddOns\\PadType\\Textures\\wedge_fill.png")
    fill:SetAllPoints(wheel)
    fill:SetRotation(-math.rad((group - 1) * 45))
    wheelWedgeFills[group] = fill
    local wedge = wheel:CreateTexture(nil, "ARTWORK")
    wedge:SetTexture(wedgeTexturePath)
    wedge:SetAllPoints(wheel)
    -- The source wedge points north; negative rotation moves clockwise around the wheel.
    wedge:SetRotation(-math.rad((group - 1) * 45))
    wheelWedges[group] = wedge
end

local function makeBadge(parent, label, size, x, y, color, iconPath, actionIconPath)
    local badge = CreateFrame("Frame", nil, parent)
    badge:SetSize(size, size)
    badge:SetPoint("CENTER", parent, "CENTER", x, y)
    badge.icon = badge:CreateTexture(nil, "BACKGROUND")
    local iconSize = (size - 5.5) * 1.15
    badge.icon:SetSize(iconSize, iconSize)
    badge.icon:SetPoint("CENTER")
    if iconPath then
        badge.icon:SetTexture(iconPath)
        badge.icon:SetVertexColor(1, 1, 1, 1)
        badge.icon:SetTexCoord(0, 1, 0, 1)
    else
        badge.icon:SetColorTexture(0.035, 0.025, 0.014, 0.98)
    end
    local fs = makeText(badge, "OVERLAY", "GameFontHighlightSmall", actionIconPath and "" or label)
    fs:SetPoint("CENTER")
    fs:SetWidth(size - 4)
    fs:SetJustifyH("CENTER")
    if iconPath then
        -- Use the same white lettering on every button color.
        fs:SetTextColor(0.96, 0.98, 1)
    else
        fs:SetTextColor(unpack(color))
    end
    fs:SetShadowColor(0, 0, 0, 0.8)
    fs:SetShadowOffset(1, -1)
    badge.label = fs
    if actionIconPath then
        badge.actionIcon = badge:CreateTexture(nil, "OVERLAY")
        -- Use the source alpha as a silhouette so the symbols render pure white.
        badge.actionIcon:SetColorTexture(1, 1, 1, 1)
        badge.actionIcon:SetSize(size * 0.63, size * 0.63)
        badge.actionIcon:SetPoint("CENTER")
        badge.actionMask = badge:CreateMaskTexture()
        badge.actionMask:SetTexture(actionIconPath, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        badge.actionMask:SetAllPoints(badge.actionIcon)
        badge.actionIcon:AddMaskTexture(badge.actionMask)
    end
    return badge
end

local function pulseCharacter(fontString)
    fontString:SetScale(1.55)
    if C_Timer and C_Timer.After then
        C_Timer.After(0.14, function()
            fontString:SetScale(1)
        end)
    else
        fontString:SetScale(1)
    end
end

local function selectGroup(index)
    currentGroup = index
    local color = backgroundColors[preferences.background]
    local function fill(texture, selected, alpha)
        local lift = selected and 0.14 or 0
        texture:SetVertexColor(color[2] + lift, color[3] + lift, color[4] + lift, alpha)
    end
    for i = 1, 8 do
        local selected = not specialMode and i == index
        local wedge = wheelWedges[i]
        fill(wheelWedgeFills[i], selected, 0.98)
        wedge:SetVertexColor(selected and 0.98 or 0.40,
            selected and 0.73 or 0.29, selected and 0.34 or 0.15, 1)
    end
    if centerGroup then
        local selected = not specialMode and index == 0
        centerGroup.rim:SetColorTexture(selected and 0.98 or 0.39, selected and 0.69 or 0.27, selected and 0.23 or 0.12, 1)
        centerGroup.inner:SetColorTexture(1, 1, 1, 1)
        fill(centerGroup.inner, selected, selected and 0.98 or 0.94)
    end
    if specialGroup then
        specialGroup.rim:SetColorTexture(specialMode and 0.98 or 0.39, specialMode and 0.69 or 0.27, specialMode and 0.23 or 0.12, 1)
        specialGroup.inner:SetColorTexture(1, 1, 1, 1)
        fill(specialGroup.inner, specialMode, specialMode and 0.98 or 0.94)
    end
end

local function updateLabels()
    pageLabel:SetText(pages[currentPage].name)
    for index, dot in ipairs(pageDots) do
        local selected = index == currentPage
        dot.rim:SetColorTexture(selected and 1 or 0.65, selected and 0.82 or 0.65,
            selected and 0 or 0.59, 1)
        dot.fill:SetColorTexture(selected and 1 or 0.018, selected and 0.82 or 0.016,
            selected and 0 or 0.012, 1)
    end
    for g = 1, 8 do
        for slot = 1, 4 do
            groupButtons[g].badges[slot].label:SetText(setButtonText(pages[currentPage].groups[g][slot]))
        end
    end
    selectGroup(currentGroup)
end

for group = 1, 8 do
    local angle = math.rad(90 - (group - 1) * 45)
    local card = CreateFrame("Frame", nil, panel)
    card:SetSize(76, 76)
    card:SetPoint("CENTER", panel, "CENTER", math.cos(angle) * groupRadius, math.sin(angle) * groupRadius - 12)
    card.badges = {}
    for slot = 1, 4 do
        card.badges[slot] = makeBadge(card, "", 22, buttonOffsets[slot][1], buttonOffsets[slot][2], faceColors[slot], buttonIconPaths[slot])
        local label = card.badges[slot].label
        local font, fontSize, flags = label:GetFont()
        label:SetFont(font, fontSize + 2, flags)
    end
    groupButtons[group] = card
end

centerGroup = CreateFrame("Frame", nil, panel)
createCircle(centerGroup, 112)
centerGroup:SetPoint("CENTER", panel, "CENTER", 0, -12)
centerGroup.chars = {}
local centerButtonOffsets = {
    { 0, 30 }, { 30, 0 }, { 0, -30 }, { -30, 0 },
}
for slot = 1, 4 do
    local value = ({ "Enter", "esc", "Space", "⌫" })[slot]
    local badge = makeBadge(centerGroup, value, 42,
        centerButtonOffsets[slot][1], centerButtonOffsets[slot][2], faceColors[slot],
        buttonIconPaths[slot], centerActionIconPaths[slot])
    centerGroup.chars[slot] = badge.actionIcon or badge.label
end

specialGroup = CreateFrame("Frame", nil, panel)
createCircle(specialGroup, 112)
specialGroup:SetPoint("CENTER", panel, "CENTER", 158, 85)
specialGroup.badges = {}
local specialActions = { "/p ", "/raid ", "/reply ", "/s " } -- Y, B, A, X
local specialLabels = { "/p", "/raid", "/reply", "/s" }
local specialOffsets = { { 0, 30 }, { 30, 0 }, { 0, -30 }, { -30, 0 } }
for slot = 1, 4 do
    specialGroup.badges[slot] = makeBadge(specialGroup, specialLabels[slot], 42,
        specialOffsets[slot][1], specialOffsets[slot][2], faceColors[slot], buttonIconPaths[slot])
end
specialGroup:Hide()

local function isAuctionHouseField(editBox)
    -- Check ancestry on demand: the auction UI may load after PadType.
    local frame = editBox
    while frame do
        local name = frame.GetName and frame:GetName()
        if frame == _G.AuctionHouseFrame or frame == _G.AuctionFrame
            or name == "AuctionHouseFrame" or name == "AuctionFrame" then
            return true
        end
        frame = frame.GetParent and frame:GetParent()
    end
    return false
end

local function insertText(editBox, text)
    -- Pass the native method directly, rather than an addon-owned closure.
    -- Test whether this boundary keeps synchronous Blizzard text-change callbacks
    -- from inheriting our execution taint. It does not authorize protected actions
    -- or remove taint already stored in Blizzard UI state.
    if securecallfunction then
        securecallfunction(editBox.Insert, editBox, text)
    else
        editBox:Insert(text)
    end
end

local function insert(value)
    if not activeEditBox or not activeEditBox:IsShown() then return end
    if isAuctionHouseField(activeEditBox) then return end
    if value == "⌫" then
        local cursor = activeEditBox:GetCursorPosition()
        if cursor and cursor > 0 then
            activeEditBox:HighlightText(cursor - 1, cursor)
            insertText(activeEditBox, "")
            activeEditBox:SetCursorPosition(cursor - 1)
        end
    elseif value == "Space" then
        insertText(activeEditBox, " ")
    elseif value == "Enter" then
        if activeEditBox:GetScript("OnEnterPressed") then
            activeEditBox:GetScript("OnEnterPressed")(activeEditBox)
        else
            insertText(activeEditBox, "\n")
        end
    elseif value == "Escape" then
        local onEscape = activeEditBox:GetScript("OnEscapePressed")
        if onEscape then
            onEscape(activeEditBox)
        else
            activeEditBox:ClearFocus()
        end
    else
        insertText(activeEditBox, isShifted and value:match("^[a-z]$") and value:upper() or value)
    end
end

local function setPage(direction)
    currentPage = ((currentPage - 1 + direction) % #pages) + 1
    updateLabels()
end

-- Coordinates here are UIParent units, independent of the keyboard's scale.
local function centerInRoot(frame)
    local x, y = frame:GetCenter()
    if not x then return end
    local ratio = frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return x * ratio, y * ratio
end

local function positionPanel(x, y)
    local scale = panel:GetEffectiveScale() / UIParent:GetEffectiveScale()
    local halfW, halfH = panel:GetWidth() * scale / 2, panel:GetHeight() * scale / 2
    x = math.max(halfW, math.min(UIParent:GetWidth() - halfW, x))
    y = math.max(halfH, math.min(UIParent:GetHeight() - halfH, y))
    panel:ClearAllPoints()
    panel:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x / scale, y / scale)
end

applyAppearance = function()
    local x, y = centerInRoot(panel)
    panel:SetScale(baseScale * preferences.size / 100)
    if x then positionPanel(x, y) end
    local color = backgroundColors[preferences.background]
    for _, background in ipairs(menuBackgrounds) do
        colorBand(background, color[2] * 0.35, color[3] * 0.35, color[4] * 0.35, 0.90)
    end
    selectGroup(currentGroup)
    refreshSettings()
end

monitor:RegisterEvent("ADDON_LOADED")
monitor:SetScript("OnEvent", function(self, event, loadedAddon)
    if loadedAddon ~= addonName then return end
    if type(PadTypeDB) ~= "table" then PadTypeDB = {} end
    local size = tonumber(PadTypeDB.size) or 100
    if size ~= size then size = 100 end
    PadTypeDB.size = math.max(70, math.min(130, math.floor(size / 10 + 0.5) * 10))
    local color = tonumber(PadTypeDB.background)
    PadTypeDB.background = color and backgroundColors[color] and color or 1
    preferences = PadTypeDB
    applyAppearance()
    self:UnregisterEvent("ADDON_LOADED")
end)

local connector = CreateFrame("Frame", nil, UIParent)
connector:SetAllPoints(UIParent)
connector:SetFrameStrata("DIALOG")
connector:SetFrameLevel(99)
connector:EnableMouse(false)
local inputLine = connector:CreateLine(nil, "ARTWORK")
inputLine:SetColorTexture(0.60, 0.39, 0.18, 0.9)
inputLine:SetThickness(2)
connector:Hide()

panel:SetScript("OnUpdate", function(self, elapsed)
    if moveX ~= 0 or moveY ~= 0 then
        local x, y = centerInRoot(panel)
        if x then
            panel:StopMovingOrSizing()
            positionPanel(x + moveX * 420 * math.min(elapsed, 0.05),
                y + moveY * 420 * math.min(elapsed, 0.05))
        end
    end
    if not activeEditBox or not activeEditBox:IsVisible() then connector:Hide(); return end
    local tx, ty = centerInRoot(activeEditBox)
    local wx, wy = centerInRoot(wheel)
    if not tx or not wx then connector:Hide(); return end
    local dx, dy = wx - tx, wy - ty
    local distance = math.sqrt(dx * dx + dy * dy)
    local radius = wheel:GetWidth() * wheel:GetEffectiveScale() / UIParent:GetEffectiveScale() / 2
    local ratio = activeEditBox:GetEffectiveScale() / UIParent:GetEffectiveScale()
    local halfW, halfH = activeEditBox:GetWidth() * ratio / 2, activeEditBox:GetHeight() * ratio / 2
    local fraction = math.min(dx ~= 0 and halfW / math.abs(dx) or math.huge,
        dy ~= 0 and halfH / math.abs(dy) or math.huge)
    if distance <= radius or fraction >= 1 - radius / distance then connector:Hide(); return end
    inputLine:SetStartPoint("BOTTOMLEFT", UIParent, tx + dx * fraction, ty + dy * fraction)
    inputLine:SetEndPoint("BOTTOMLEFT", UIParent, wx - dx / distance * radius, wy - dy / distance * radius)
    connector:Show()
end)
panel:SetScript("OnHide", function()
    moveX, moveY = 0, 0
    connector:Hide()
end)

local function toggleSettings()
    if settings:IsShown() then
        settings:Hide()
    else
        specialMode = false
        specialGroup:Hide()
        selectGroup(0)
        settings:Show()
    end
end

local function showFor(editBox)
    if not editBox or not editBox.GetObjectType or editBox:GetObjectType() ~= "EditBox" then return end
    if isAuctionHouseField(editBox) then return end
    activeEditBox = editBox
    dismissedEditBox = nil
    -- Diagnostic: leave native movement settings untouched to isolate gamepad taint.
    panel:Show()
    panel:EnableGamePadButton(true)
    panel:EnableGamePadStick(true)
    updateLabels()
end

local function hideKeyboard()
    settings:Hide()
    specialMode = false
    if specialGroup then specialGroup:Hide() end
    panel:Hide()
    panel:EnableGamePadButton(false)
    panel:EnableGamePadStick(false)
    dismissedEditBox = activeEditBox
    activeEditBox = nil
end

local function getFocusedEditBox()
    if GetCurrentKeyBoardFocus then
        local focus = GetCurrentKeyBoardFocus()
        if focus and focus.GetObjectType and focus:GetObjectType() == "EditBox" then return focus end
    end
end

monitor:SetScript("OnUpdate", function(self)
    local focused = getFocusedEditBox()
    if isAuctionHouseField(focused) then
        if panel:IsShown() then hideKeyboard() end
        return
    end
    -- Clicking our settings controls may release text focus. Keep the dialog
    -- alive only while its original target remains visible.
    if settings:IsShown() then
        if not focused and activeEditBox and activeEditBox:IsShown() then return end
        if focused ~= activeEditBox then settings:Hide() end
    end
    if not focused then dismissedEditBox = nil end
    if focused and not panel:IsShown() and focused ~= dismissedEditBox then
        showFor(focused)
    elseif focused and focused ~= activeEditBox then
        activeEditBox = focused
    elseif not focused and panel:IsShown() then
        hideKeyboard()
    end
end)

panel:SetScript("OnGamePadStick", function(self, stick, x, y, length)
    if not panel:IsShown() then return end
    if stick == "RStick" or stick == "Right" or stick == 2 then
        x, y = x or 0, y or 0
        local magnitude = math.sqrt(x * x + y * y)
        if magnitude < 0.20 then moveX, moveY = 0, 0
        else
            local speed = (math.min(magnitude, 1) - 0.20) / 0.80
            moveX, moveY = x / magnitude * speed, y / magnitude * speed
        end
        return
    end
    if settings:IsShown() then return end
    if specialMode then return end
    -- WoW reports the stick as LStick on current clients. Also accept enum-style names.
    if stick ~= "LStick" and stick ~= "Left" and stick ~= 1 then return end
    x, y = x or 0, y or 0
    local stickLength = length or 0
    if stickLength < stickDeadZone then
        selectGroup(0)
        return
    end
    local degrees = math.deg(math.atan2(y, x))
    -- Directional groups begin at north and proceed clockwise.
    local index = (math.floor(((90 - degrees) % 360) / 45 + 0.5) % 8) + 1
    selectGroup(index)
end)

panel:SetScript("OnGamePadButtonDown", function(self, button)
    if not panel:IsShown() then return end
    -- Focus can change before the next OnUpdate; do not handle that input.
    if isAuctionHouseField(getFocusedEditBox()) then
        hideKeyboard()
        return
    end
    -- Start/Menu is PADFORWARD; also retain support for system-button mappings.
    if button == "PADFORWARD" or button == "PADSYSTEM" then
        toggleSettings()
        return
    end
    if settings:IsShown() then
        if button == "PAD2" then settings:Hide()
        elseif button == "PADBACK" or button == "PADSOCIAL" then hideKeyboard() end
        if button == "PADDUP" or button == "PADDDOWN" then
            settingsRow = 3 - settingsRow
            refreshSettings()
        elseif button == "PADDLEFT" then changeSetting(settingsRow, -1)
        elseif button == "PADDRIGHT" or button == "PAD1" then changeSetting(settingsRow, 1) end
        return
    end
    if button == "PADRTRIGGER" then
        specialMode = true
        specialGroup:Show()
        selectGroup(currentGroup)
        return
    end
    local slot
    if button == "PAD1" then slot = 3 -- A / bottom
    elseif button == "PAD2" then slot = 2 -- B / right
    elseif button == "PAD3" then slot = 4 -- X / left
    elseif button == "PAD4" then slot = 1 -- Y / top
    end
    if slot then
        if specialMode then
            pulseCharacter(specialGroup.badges[slot].label)
            insert(specialActions[slot])
        elseif currentGroup == 0 then
            pulseCharacter(centerGroup.chars[slot])
            local centerActions = { "Enter", "Escape", "Space", "⌫" }
            insert(centerActions[slot])
        else
            pulseCharacter(groupButtons[currentGroup].badges[slot].label)
            insert(pages[currentPage].groups[currentGroup][slot])
        end
    elseif button == "PADLSHOULDER" then setPage(-1)
    elseif button == "PADRSHOULDER" then setPage(1)
    elseif button == "PADLTRIGGER" then isShifted = not isShifted; updateLabels()
    elseif button == "PADBACK" or button == "PADSOCIAL" then hideKeyboard()
    end
end)

panel:SetScript("OnGamePadButtonUp", function(self, button)
    if button == "PADRTRIGGER" and specialMode then
        specialMode = false
        specialGroup:Hide()
        selectGroup(currentGroup)
    end
end)

panel:SetScript("OnMouseDown", function() panel:StartMoving() end)
panel:SetScript("OnMouseUp", function() panel:StopMovingOrSizing() end)

SLASH_PADTYPE1 = "/padtype"
SlashCmdList.PADTYPE = function(command)
    command = (command or ""):lower()
    if command == "hide" or panel:IsShown() then
        hideKeyboard()
        return
    end
    local focus = getFocusedEditBox()
    if isAuctionHouseField(focus) then
        print("PadType: disabled for auction-house fields due to a native gamepad compatibility issue.")
    elseif focus then
        showFor(focus)
    else
        print("PadType: focus a text field first, then run /padtype.")
    end
end

updateLabels()
applyAppearance()
